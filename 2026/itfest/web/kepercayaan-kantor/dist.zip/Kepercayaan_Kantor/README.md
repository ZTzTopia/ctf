# Web Kantor

Sistem catatan/peninjauan internal. Setiap catatan yang dikirim akan
ditinjau oleh bot administrator.

## Menjalankan lokal

```bash
docker compose up --build
```

Buka http://localhost:8080

Flag lokal hanya placeholder; flag asli ada di instance challenge.

## Struktur
- `app/` aplikasi web
- `bot/` admin bot peninjau
- `docker-compose.yml`
