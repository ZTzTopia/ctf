from flask import Flask, render_template, request, Response, make_response, jsonify
import os
import hashlib
import requests
from urllib.parse import urlparse, quote

app = Flask(__name__)

FLAG = os.environ.get("FLAG", "ITFest2026{dummy}")
ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN", "changeme")

WEB_HOST = os.environ.get("WEB_HOST", "http://web:5000").rstrip("/")
_wh = urlparse(WEB_HOST)
INTERNAL_NETLOC = _wh.netloc or "web:5000"
INTERNAL_SCHEME = _wh.scheme or "http"

CSRF = hashlib.md5(("csrf|" + ADMIN_TOKEN).encode()).hexdigest()

CSP = (
    "default-src 'self'; "
    "script-src 'self' 'unsafe-inline'; "
    "style-src 'self' 'unsafe-inline'; "
    "img-src 'self'; "
    "connect-src 'self'; "
    "frame-src 'none'; "
    "base-uri 'none'; "
    "require-trusted-types-for 'script'; "
    "trusted-types notePolicy;"
)


def is_admin(req):
    return req.cookies.get('admin_session') == ADMIN_TOKEN


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/view')
def view():
    resp = make_response(render_template('view.html'))
    resp.headers['Content-Security-Policy'] = CSP
    return resp


@app.route('/admin/dashboard')
def admin_dashboard():
    if not is_admin(request):
        return Response("Forbidden", status=403)
    resp = make_response(render_template('dashboard.html', csrf=CSRF))
    resp.headers['Content-Security-Policy'] = CSP
    return resp


@app.route('/admin/flag', methods=['POST'])
def admin_flag():
    if not is_admin(request):
        return Response("Forbidden", status=403)
    if request.form.get('csrf') != CSRF:
        return Response("Bad CSRF token", status=403)
    return Response(FLAG, mimetype='text/plain')


@app.route('/report', methods=['GET', 'POST'])
def report():
    if request.method == 'POST':
        url = request.form.get('url')
        if not url or not url.startswith('http'):
            return "Invalid URL", 400

        try:
            parsed = urlparse(url)
            if parsed.path:
                url = parsed._replace(scheme=INTERNAL_SCHEME, netloc=INTERNAL_NETLOC).geturl()
        except Exception:
            pass

        try:
            bot_url = os.environ.get('BOT_URL', 'http://bot:3000/visit')
            r = requests.post(bot_url, json={'url': url}, timeout=5)
            if r.status_code == 200:
                return render_template('report.html', msg="Admin will review your note shortly.")
            return render_template('report.html', msg=f"Admin bot rejected the URL: {r.text}")
        except Exception:
            return render_template('report.html', msg="Failed to contact admin bot.")

    return render_template('report.html')


@app.route('/api/health')
def api_health():
    return jsonify(status="ok", app="web-kantor", version="1.0")


@app.route('/api/report', methods=['POST'])
def api_report():
    data = request.get_json(silent=True) or {}
    rule = data.get('rule')
    if not isinstance(rule, str) or not rule.strip():
        return jsonify(ok=False, error="Field 'rule' wajib diisi"), 400

    view_url = WEB_HOST + '/view?rule=' + quote(rule, safe='')
    try:
        bot_url = os.environ.get('BOT_URL', 'http://bot:3000/visit')
        r = requests.post(bot_url, json={'url': view_url}, timeout=5)
        if r.status_code == 200:
            return jsonify(ok=True,
                           message="Catatan dikirim. Bot admin akan segera meninjau.",
                           view_url=view_url)
        return jsonify(ok=False, error=f"Bot menolak: {r.text}"), 502
    except Exception:
        return jsonify(ok=False, error="Gagal menghubungi bot admin."), 502


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
